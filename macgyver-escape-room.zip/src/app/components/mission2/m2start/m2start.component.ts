import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m2start',
  templateUrl: './m2start.component.html',
  styleUrls: ['./m2start.component.css']
})
export class M2startComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
