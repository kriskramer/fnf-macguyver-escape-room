import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m2finish',
  templateUrl: './m2finish.component.html',
  styleUrls: ['./m2finish.component.css']
})
export class M2finishComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
