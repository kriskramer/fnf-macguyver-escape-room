import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m1main',
  templateUrl: './m1start.component.html',
  styleUrls: ['./m1start.component.css']
})
export class M1StartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
