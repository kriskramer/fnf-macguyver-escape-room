import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m1finish',
  templateUrl: './m1finish.component.html',
  styleUrls: ['./m1finish.component.css']
})
export class M1finishComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
